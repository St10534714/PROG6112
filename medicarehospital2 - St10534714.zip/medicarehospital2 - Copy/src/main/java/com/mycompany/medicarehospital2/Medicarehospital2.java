/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.medicarehospital2;

/**
 *
 * @author Student
 */
public class Medicarehospital2 {

    public static void main(String[] args) {
      
    }
}
