/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medicarehospital2;

/**
 *
 * @author Student
 */


import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Hospital {

    private ArrayList<Patient> patients;
    private String[][] beds;

    public Hospital() {
 
        patients = new ArrayList<>();

        // 4 rows and 5 columns = 20 beds
        beds = new String[4][5];

        int bedNumber = 1;

        for (int row = 0; row < 4; row++) {

            for (int col = 0; col < 5; col++) {

                beds[row][col] =
                        "B" + String.format("%02d", bedNumber);

                bedNumber++;
            }
        }
    }

    

    public boolean registerPatient(Patient patient) {

    if (searchPatient(patient.getPatientID()) != null) {

    System.out.println("Patient ID already exists.");

    return false;
    }

   patients.add(patient);

  System.out.println("Patient registered successfully.");

        return true;
    }

    public Patient searchPatient(String patientID) {

        for (Patient patient : patients) {

            if (patient.getPatientID()
                    .equalsIgnoreCase(patientID)) {

                return patient;
            }
        }

        return null;
    }

    public boolean updatePatient(String patientID,
                                 String firstName,
                                 String lastName,
                                 int age,
                                 String gender,
                                 String medicalCondition) {

        Patient patient = searchPatient(patientID);

        if (patient == null) {
            return false;
        }

        patient.setFirstName(firstName);
        patient.setLastName(lastName);
        patient.setAge(age);
        patient.setGender(gender);
        patient.setMedicalCondition(medicalCondition);

        return true;
    }

    public boolean deletePatient(String patientID) {

        Patient patient = searchPatient(patientID);

        if (patient == null) {
            return false;
        }

        if (patient instanceof Inpatient) {

            Inpatient inpatient = (Inpatient) patient;

            releaseBed(inpatient.getBedNumber());
        }

        patients.remove(patient);

        return true;
    }

    public int getTotalPatients() {
        return patients.size();
    }

   

    public void displayAllBeds() {

        System.out.println("\n===== WARD BED LAYOUT =====");

        for (int row = 0; row < 4; row++) {

            for (int col = 0; col < 5; col++) {

                System.out.print(beds[row][col] + "\t");
            }

            System.out.println();
        }
    }

    public boolean isBedAvailable(String bedNumber) {

        int row = findRow(bedNumber);
        int col = findColumn(bedNumber);

        if (row == -1 || col == -1) {
            return false;
        }

        return !beds[row][col].contains("-OCCUPIED");
    }

    public boolean allocateBed(String patientID,
                               String bedNumber) {

        Patient patient = searchPatient(patientID);

        if (patient == null) {

            System.out.println("Patient not found.");

            return false;
        }

        if (patient.getCategory() != Patientcategory.INPATIENT) {

            System.out.println(
                    "Only inpatients can be allocated a bed.");

            return false;
        }

        int row = findRow(bedNumber);
        int col = findColumn(bedNumber);

        if (row == -1 || col == -1) {

            System.out.println("Bed does not exist.");

            return false;
        }

        if (!isBedAvailable(bedNumber)) {

            System.out.println("Bed is already occupied.");

            return false;
        }

        Inpatient inpatient = (Inpatient) patient;

        if (inpatient.getBedNumber() != null) {

            System.out.println(
                    "Patient already has a bed.");

            return false;
        }

        beds[row][col] = bedNumber + "-OCCUPIED";

        inpatient.setBedNumber(bedNumber);

        System.out.println("Bed allocated successfully.");

        return true;
    }

    public boolean releaseBed(String bedNumber) {

        if (bedNumber == null) {
            return false;
        }

        int row = findRow(bedNumber);
        int col = findColumn(bedNumber);

        if (row == -1 || col == -1) {
            return false;
        }

        if (!beds[row][col].contains("-OCCUPIED")) {

            return false;
        }

        beds[row][col] = bedNumber;

        for (Patient patient : patients) {

            if (patient instanceof Inpatient) {

                Inpatient inpatient =
                        (Inpatient) patient;

                if (bedNumber.equalsIgnoreCase(
                        inpatient.getBedNumber())) {

                    inpatient.setBedNumber(null);
                }
            }
        }

        System.out.println("Bed released successfully.");

        return true;
    }

    private int findRow(String bedNumber) {

        if (bedNumber == null) {
            return -1;
        }

        for (int row = 0; row < 4; row++) {

            for (int col = 0; col < 5; col++) {

                String bed = beds[row][col];

                if (bed.equalsIgnoreCase(bedNumber)
                        || bed.equalsIgnoreCase(
                        bedNumber + "-OCCUPIED")) {

                    return row;
                }
            }
        }

        return -1;
    }

    private int findColumn(String bedNumber) {

        if (bedNumber == null) {
            return -1;
        }

        for (int row = 0; row < 4; row++) {

            for (int col = 0; col < 5; col++) {

                String bed = beds[row][col];

                if (bed.equalsIgnoreCase(bedNumber)
                        || bed.equalsIgnoreCase(
                        bedNumber + "-OCCUPIED")) {

                    return col;
                }
            }
        }

        return -1;
    }

    

    public void displayAvailableBeds() {

        System.out.println("\n===== AVAILABLE BEDS =====");

        boolean found = false;

        for (int row = 0; row < 4; row++) {

            for (int col = 0; col < 5; col++) {

                if (!beds[row][col].contains("-OCCUPIED")) {

                    System.out.print(beds[row][col] + " ");

                    found = true;
                }
            }
        }

        if (!found) {
            System.out.println("No beds available.");
        }

        System.out.println();
    }

   

    public void displayOccupiedBeds() {

        System.out.println("\n===== OCCUPIED BEDS =====");

        boolean found = false;

        for (int row = 0; row < 4; row++) {

            for (int col = 0; col < 5; col++) {

                if (beds[row][col].contains("-OCCUPIED")) {

                    System.out.print(beds[row][col] + " ");

                    found = true;
                }
            }
        }

        if (!found) {
            System.out.println("No occupied beds.");
        }

        System.out.println();
    }

  

    public void displayPatientReport() {

        System.out.println("\n===== PATIENT REPORT =====");

        if (patients.isEmpty()) {

            System.out.println("No patients registered.");

            return;
        }

        for (Patient patient : patients) {

            System.out.println("--------------------------");

            patient.displayDetails();
        }
    }

    public int getOccupiedBeds() {

        int count = 0;

        for (int row = 0; row < 4; row++) {

            for (int col = 0; col < 5; col++) {

                if (beds[row][col].contains("-OCCUPIED")) {

                    count++;
                }
            }
        }

        return count;
    }

    public double getOccupancyPercentage() {

        return (getOccupiedBeds() / 20.0) * 100;
    }

    public void displayBedReport() {

        System.out.println("\n===== BED OCCUPANCY REPORT =====");

        System.out.println("Total beds: 20");

        System.out.println(
                "Occupied beds: " + getOccupiedBeds());

        System.out.println(
                "Available beds: " +
                (20 - getOccupiedBeds()));

        System.out.println(
                "Occupancy percentage: " +
                getOccupancyPercentage() + "%");
    }

    // =========================
    // SORTING
    // =========================

    public void sortBySurname() {

        Collections.sort(patients,
                new Comparator<Patient>() {

            @Override
            public int compare(Patient p1, Patient p2) {

                return p1.getLastName()
                        .compareToIgnoreCase(
                                p2.getLastName());
            }
        });

        System.out.println(
                "Patients sorted by surname.");
    }

    public void sortByPatientID() {

        Collections.sort(patients,
                new Comparator<Patient>() {

            @Override
            public int compare(Patient p1, Patient p2) {

                return p1.getPatientID()
                        .compareToIgnoreCase(
                                p2.getPatientID());
            }
        });

        System.out.println(
                "Patients sorted by Patient ID.");
    }
}
    

