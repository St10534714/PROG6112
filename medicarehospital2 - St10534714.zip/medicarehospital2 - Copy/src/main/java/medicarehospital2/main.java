/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package medicarehospital2;

/**
 *
 * @author Student
 */

import java.util.Scanner;

public class main {

    public static void main(String[] args) {
 
        Scanner input = new Scanner(System.in);

        Hospital hospital = new Hospital();
   
        int choice = 0;

        while (choice != 13) {

            System.out.println("\n=================================");
            System.out.println("     MEDICARE HOSPITAL SYSTEM");
            System.out.println("=================================");
            System.out.println("1. Register Patient");
            System.out.println("2. Search Patient");
            System.out.println("3. Update Patient");
            System.out.println("4. Delete Patient");
            System.out.println("5. Allocate Bed");
            System.out.println("6. Release Bed");
            System.out.println("7. Display Ward Layout");
            System.out.println("8. Display Available Beds");
            System.out.println("9. Display Occupied Beds");
            System.out.println("10. Patient Report");
            System.out.println("11. Bed Occupancy Report");
            System.out.println("12. Sort Patients");
            System.out.println("13. Exit");
            System.out.println("=================================");

            try {

                System.out.print("Enter your choice: ");

                choice = Integer.parseInt(
                        input.nextLine());

                switch (choice) {

                    case 1:
                        registerPatient(input, hospital);
                        break;

                    case 2:
                        searchPatient(input, hospital);
                        break;

                    case 3:
                        updatePatient(input, hospital);
                        break;

                    case 4:
                        deletePatient(input, hospital);
                        break;

                    case 5:
                        allocateBed(input, hospital);
                        break;

                    case 6:
                        releaseBed(input, hospital);
                        break;

                    case 7:
                        hospital.displayAllBeds();
                        break;

                    case 8:
                        hospital.displayAvailableBeds();
                        break;

                    case 9:
                        hospital.displayOccupiedBeds();
                        break;

                    case 10:
                        hospital.displayPatientReport();
                        break;

                    case 11:
                        hospital.displayBedReport();
                        break;

                    case 12:
                        sortPatients(input, hospital);
                        break;

                    case 13:
                        System.out.println(
                                "Thank you for using "
                                + "MediCare Hospital System.");
                        break;

                    default:
                        System.out.println(
                                "Invalid choice.");
                }

            } catch (Exception e) {

                System.out.println(
                        "Please enter valid information.");
            }
        }

        input.close();
    }

    public static void registerPatient(
            Scanner input, Hospital hospital) {

        System.out.println(
                "\n===== REGISTER PATIENT =====");

        System.out.print("Enter Patient ID: ");
        String id = input.nextLine();

        System.out.print("Enter First Name: ");
        String firstName = input.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = input.nextLine();

        System.out.print("Enter Age: ");
        int age = Integer.parseInt(input.nextLine());

        System.out.print("Enter Gender: ");
        String gender = input.nextLine();

        System.out.print("Enter Medical Condition: ");
        String condition = input.nextLine();

        System.out.println(
                "1. Inpatient");
        System.out.println(
                "2. Outpatient");
        System.out.println(
                "3. Emergency");

        System.out.print(
                "Choose Patient Category: ");

        int category =
                Integer.parseInt(input.nextLine());

        if (category == 1) {

            Inpatient patient =
                    new Inpatient(
                            id,
                            firstName,
                            lastName,
                            age,
                            gender,
                            condition,
                            "Ward 1",
                            null);

            hospital.registerPatient(patient);

        } else if (category == 2) {

            Patient patient =
                    new Patient(
                            id,
                            firstName,
                            lastName,
                            age,
                            gender,
                            condition,
                            Patientcategory.OUTPATIENT);

            hospital.registerPatient(patient);

        } else if (category == 3) {

            Patient patient =
                    new Patient(
                            id,
                            firstName,
                            lastName,
                            age,
                            gender,
                            condition,
                            Patientcategory.EMERGENCY);

            hospital.registerPatient(patient);

        } else {

            System.out.println(
                    "Invalid category.");
        }
    }

    public static void searchPatient(
            Scanner input, Hospital hospital) {

        System.out.println(
                "\n===== SEARCH PATIENT =====");

        System.out.print(
                "Enter Patient ID: ");

        String id = input.nextLine();

        Patient patient =
                hospital.searchPatient(id);

        if (patient != null) {

            patient.displayDetails();

        } else {

            System.out.println(
                    "Patient not found.");
        }
    }

    public static void updatePatient(
            Scanner input, Hospital hospital) {

        System.out.println(
                "\n===== UPDATE PATIENT =====");

        System.out.print(
                "Enter Patient ID: ");

        String id = input.nextLine();

        Patient patient =
                hospital.searchPatient(id);

        if (patient == null) {

            System.out.println(
                    "Patient not found.");

            return;
        }

        System.out.print(
                "Enter new First Name: ");

        String firstName =
                input.nextLine();

        System.out.print(
                "Enter new Last Name: ");

        String lastName =
                input.nextLine();

        System.out.print(
                "Enter new Age: ");

        int age =
                Integer.parseInt(
                        input.nextLine());

        System.out.print(
                "Enter new Gender: ");

        String gender =
                input.nextLine();

        System.out.print(
                "Enter new Medical Condition: ");

        String condition =
                input.nextLine();

        boolean result =
                hospital.updatePatient(
                        id,
                        firstName,
                        lastName,
                        age,
                        gender,
                        condition);

        if (result) {

            System.out.println(
                    "Patient updated successfully.");

        } else {

            System.out.println(
                    "Patient could not be updated.");
        }
    }

    public static void deletePatient(
            Scanner input, Hospital hospital) {

        System.out.println(
                "\n===== DELETE PATIENT =====");

        System.out.print(
                "Enter Patient ID: ");

        String id = input.nextLine();

        boolean result =
                hospital.deletePatient(id);

        if (result) {

            System.out.println(
                    "Patient deleted successfully.");

        } else {

            System.out.println(
                    "Patient not found.");
        }
    }

    public static void allocateBed(
            Scanner input, Hospital hospital) {

        System.out.println(
                "\n===== ALLOCATE BED =====");

        System.out.print(
                "Enter Patient ID: ");

        String patientID =
                input.nextLine();

        System.out.print(
                "Enter Bed Number (B01-B20): ");

        String bedNumber =
                input.nextLine();

        hospital.allocateBed(
                patientID,
                bedNumber);
    }

    public static void releaseBed(
            Scanner input, Hospital hospital) {

        System.out.println(
                "\n===== RELEASE BED =====");

        System.out.print(
                "Enter Bed Number: ");

        String bedNumber =
                input.nextLine();

        hospital.releaseBed(
                bedNumber);
    }

    public static void sortPatients(
            Scanner input, Hospital hospital) {

        System.out.println(
                "\n===== SORT PATIENTS =====");

        System.out.println(
                "1. Sort by Surname");

        System.out.println(
                "2. Sort by Patient ID");

        System.out.print(
                "Enter choice: ");

        int choice =
                Integer.parseInt(
                        input.nextLine());

        if (choice == 1) {

            hospital.sortBySurname();

            hospital.displayPatientReport();

        } else if (choice == 2) {

            hospital.sortByPatientID();

            hospital.displayPatientReport();

        } else {

            System.out.println(
                    "Invalid choice.");
        }
    }
}
    

